package org.jacoco.core.analysis;

public abstract class AbstractCounter {
	public int add(int a, int b){
		return a+b;
	}
	public long mul(int a, int b){
		return a*b;
	}
	public int addsome(int a){
		return a+10;
	}
	public String hello(){
		return "Hello";
	}
}