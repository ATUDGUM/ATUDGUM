package cn.edu.sysu.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class CalculatorTest {
	@Test
	public void testadd() {
		assertEquals(6, Calculator.add(4,2));
	}
	@Test
	public void testsub() {
		assertEquals(2, Calculator.sub(4,2));
	}
	@Test
	public void testdivide() {
		assertEquals(2.0, Calculator.divide(4,2));
	}
	@Test
	public void testaddsome() {
		assertEquals(12, Calculator.addsome(2));
	}
	@Test
	public void testsubsome() {
		assertEquals(39990, Calculator.subsome(40000));
	}
}
