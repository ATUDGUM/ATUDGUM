package cn.edu.sysu.test;

public abstract class Calculator {
	public int add(int a, int b) {
		return a+b;
	}
	public int sub(int a, int b) {
		return a-b;
	}
	public double divide(int a, int b) {
        return (double) a / b;
    }
	public int addsome(int a){
		int s = 10;
		return a+s;
	}
	public int subsome(int a){
		int s = 10;
		return a-s;
	}
}